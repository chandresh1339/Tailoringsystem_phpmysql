<!-- Load an icon library to show a hamburger menu (bars) on small screens -->

<?php error_reporting(0); include('header_scripts.php'); $date = date("Y.m.d");?>
<style>
img {
  max-width: 100%;
  height: auto;
}
</style>
<style>
footer {
 
  position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color:#202020;
   color: white;
   text-align: center;
}
}
</style>
<link rel="stylesheet" href="public/style.css">

  <body>
<div class="topnav" id="myTopnav">
  <li  align="center"  >
 <a href="#home"><img src="tailor_logo.JPG" width="75px"></a>
</li>
  <a href="index.php">DASHBOARD</a>
  <a href="assign-a.php">Assignment</a>
  <a href="view_customers_A.php">Group A</a>
   <a href="view_customers_B.php">Group B</a>
      <a href="view_customers_C.php">Group C</a>
      <a href="global_search.php">Global Search</a>
      <li><a href="measure_a.php">Generate Receipt</a>
   
  <a href="javascript:void(0);" class="icon" onclick="myFunction()">
    <i class="fa fa-bars"></i>
  </a>
</div>
<div style="padding-left:16px">
  Today is:   <font style="color:blue;" size="5"> <?php echo $date;?></font>
</div>

<script>
function myFunction() {
  var x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
}
</script>

</div>
<footer>
  <p>Tailoring System<br>
  <a href="mailto:abc@example.com">A way to paperless...</a></p>
</footer>

