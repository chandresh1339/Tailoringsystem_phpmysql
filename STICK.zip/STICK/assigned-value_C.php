<script>history.pushState({}, "", "")</script>
<?php //error_reporting(0); 
        
    if(isset($_POST['btnmeasure']) and !empty($_POST)){
        

        $check = $_POST['checkbox'];
            if(isset($_POST['checkbox'])) {
                foreach($_POST['checkbox'] as $check) {

                    //Getting searched values from customer form
                     $id = $_GET['id'];
                     //echo $id;
                    $cust_name=$row['cust_name'];
                    //echo $cust_name;
                    $group_c=$row['group_c'];
                    $del_date=$_POST['del_date'];   
                  
       

                   $check = implode(',', $_POST['checkbox']);
                    $set_c_unit  = implode(',', $_POST['set_c_unit']);
                  $length = implode(',',$_POST['length']);
                   $neck = implode(',',$_POST['neck']);
                   $shoulder = implode(',',$_POST['shoulder']);
                    $chest = implode(',',$_POST['chest']);
                  $stomach= implode(',',$_POST['stomach']);
                    $seat= implode(',',$_POST['seat']);
                   $sleeves=implode(',',$_POST['sleeves']);
               /* echo $check . "<br>";
                echo $set_a_unit . "<br>";
                echo $length . "<br>";
                 echo $neck . "<br>";
                  echo $shoulder . "<br>";
                   echo $chest . "<br>";
                    echo  $stomach . "<br>";
                     echo  $seat . "<br>";
                     echo  $sleeves. "<br>";*/
                 $sql="INSERT INTO tbl_unit_c(set_c_unit,length,neck,shoulder,chest,stomach,seat,sleeves,checks) VALUES('$set_c_unit','$length','$neck','$shoulder','$chest','$stomach','$seat','$sleeves','$check')";

                   $result = mysqli_query($con, $sql);
               }
               
         } 
                if($result)
                {
                     $sql0 = "SELECT * FROM tbl_customer_c WHERE id = '".$id."'";
             
                     $result0 = mysqli_query($con, $sql0);
                 }
                     if($result0)
                     {
           $qry = "INSERT INTO master_alloc_c VALUES(null,' $cust_name','$group_c','$del_date','$set_c_unit','$length','$neck','$shoulder','$chest','$stomach','$seat','$sleeves','$check')";
                $result1 = mysqli_query($con, $qry);
            }

             if ($result1) {
     
                    echo "<script language='javascript'>alert('Record Inserted Successfully')
                   </script>";
                                    } else {
                                      //echo  $con->error;
                            echo "Failure" . mysqli_error($con);
                                }

}?>
