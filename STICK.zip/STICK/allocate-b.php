<script src="UNIT-B.js"></script>
<script>history.pushState({}, "", "")</script>
<body style="background-color:darkkhaki;">
        <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
          <table class="table table-bordered table-hover" id="invoiceItem"> 
            <tr><th width="2%"><input id="checkAll" class="formcontrol" type="checkbox">
            </th>
              
              <th width="10%">Set B</th>
              <th width="10%">Length</th>
              
              <th width="10%">Waist</th>               
              <th width="10%">Seat</th>
              <th width="10%">Fork</th>
              <th width="10%">Thigh</th>
              <th width="10%">Knee</th>
              <th width="10%">Bottom</th>
            </tr>             
            <tr>
              
              <td><input class="itemRow" type="checkbox" name="checkbox[]"></td>
              <td><input type="text" name="set_b_unit[]" id="set_b_unit" class="form-control" autocomplete="off"></td>
              <td><input type="float" name="length[]"  id="length" class="form-control" autocomplete="off"></td>
              <td><input type="float" name="waist[]"  id="waist" class="form-control" autocomplete="off"></td>
              <td><input type="float" name="seat[]" id="seat" class="form-control" autocomplete="off"></td>      
              <td><input type="float" name="fork[]" id="fork"  class="form-control quantity" autocomplete="off"></td>
            
              <td><input type="float" name="thigh[]" id="thigh" class="form-control " autocomplete="off"></td>
              <td><input type="float" name="knee[]" id="knee"  class="form-control" autocomplete="off"></td>
              <td><input type="float" name="bottom[]" id="bottom" class="form-control" autocomplete="off"></td>
              
            </tr>           
          </table>
        </div>
      </div>
      <div class="row">
        <div class="col-xs-12 col-sm-3 col-md-3 col-lg-3">
          <button class="btn btn-danger delete" id="removeRows" type="button">- Delete</button>
          <button class="btn btn-success" id="addRows" type="button">+ Add More</button>
        </div>
      </div>
      <!--<div class="row"> 
        <div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
          <h3>Notes: </h3>
          <div class="form-group">
            <textarea class="form-control txt" rows="3" name="notes" id="notes" placeholder="Your Notes"></textarea>
          </div>
          <br>

          <div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
            <div class="form-group">
            <input type="hidden" name="SET_a_id" class="form-control">
          </div>
                </div>
           <div >
-->
<br/>

                    <input type="submit" name="btnmeasure" class="btn btn-success " value="SAVE">

                </div>
        </div>

      </div>
    </body>



