-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Mar 09, 2021 at 04:51 AM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `invoice`
--

-- --------------------------------------------------------

--
-- Table structure for table `master_alloc_a`
--

DROP TABLE IF EXISTS `master_alloc_a`;
CREATE TABLE IF NOT EXISTS `master_alloc_a` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cust_name` varchar(150) COLLATE utf8_bin NOT NULL,
  `group_a` varchar(150) COLLATE utf8_bin NOT NULL,
  `del_date` date NOT NULL,
  `set_a_unit` longtext COLLATE utf8_bin NOT NULL,
  `length` longtext COLLATE utf8_bin NOT NULL,
  `neck` longtext COLLATE utf8_bin NOT NULL,
  `shoulder` longtext COLLATE utf8_bin NOT NULL,
  `chest` longtext COLLATE utf8_bin NOT NULL,
  `stomach` longtext COLLATE utf8_bin NOT NULL,
  `seat` longtext COLLATE utf8_bin NOT NULL,
  `sleeves` longtext COLLATE utf8_bin NOT NULL,
  `checks` varchar(150) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `master_alloc_a`
--

INSERT INTO `master_alloc_a` (`id`, `cust_name`, `group_a`, `del_date`, `set_a_unit`, `length`, `neck`, `shoulder`, `chest`, `stomach`, `seat`, `sleeves`, `checks`) VALUES
(18, ' Ganesh', 'ASIF', '2021-02-18', 'df', '2', '23', '23', '23', '23', '23', '23', 'on'),
(15, ' Ganesh', 'ASIF', '2021-02-18', 'df', '43', '34', '45', '56', '56', '56', '56', 'on'),
(16, ' Mahesh', 'ASIF', '2021-03-18', 'vestcoat', '12', '323', '23', '23', '34', '34', '34', 'on'),
(19, ' Mohan', 'ASIF', '2021-03-31', 'modicoat', '15', '50', '52', '52', '52', '52', '52', 'on'),
(20, ' Sahlu', 'ASIF', '2021-03-19', 'indowestern,joshpuri', '15.6,1.2', '6.9,6.5', '7.9,1.2', '4.8,3.2', '9.8,7.8', '1.3,9.8', '6.5,5.6', 'on'),
(21, ' Sundar', 'ASIF', '2021-03-24', 'jodhpuri', '8.2', '6.5', '1.2', '6.3', '9.8', '4.5', '5.2', 'on');

-- --------------------------------------------------------

--
-- Table structure for table `master_alloc_b`
--

DROP TABLE IF EXISTS `master_alloc_b`;
CREATE TABLE IF NOT EXISTS `master_alloc_b` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cust_name` varchar(150) COLLATE utf8_bin NOT NULL,
  `group_b` varchar(150) COLLATE utf8_bin NOT NULL,
  `del_date` date NOT NULL,
  `set_b_unit` longtext COLLATE utf8_bin NOT NULL,
  `length` longtext COLLATE utf8_bin NOT NULL,
  `waist` longtext COLLATE utf8_bin NOT NULL,
  `seat` longtext COLLATE utf8_bin NOT NULL,
  `fork` longtext COLLATE utf8_bin NOT NULL,
  `thigh` longtext COLLATE utf8_bin NOT NULL,
  `knee` longtext COLLATE utf8_bin NOT NULL,
  `bottom` longtext COLLATE utf8_bin NOT NULL,
  `checks` varchar(150) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `master_alloc_b`
--

INSERT INTO `master_alloc_b` (`id`, `cust_name`, `group_b`, `del_date`, `set_b_unit`, `length`, `waist`, `seat`, `fork`, `thigh`, `knee`, `bottom`, `checks`) VALUES
(25, ' Raghu', 'ARMAN', '2021-03-20', 'paint,pyjama', '12.2,14.2', '3.2,1.3', '6.5,6.5', '5.9,9.8', '4.5,4.7', '4.2,5.6', '9.9,9.8', 'on'),
(24, ' Mayuri', 'ARMAN', '2021-03-24', 'churidar,salwar,', '1.5,1.9,', '20,3.3,', '1.3,8.9,', '6.5,5.6,', '8.9,4.7,', '8.9,6.5,', '5.6,2.1,', 'on');

-- --------------------------------------------------------

--
-- Table structure for table `master_alloc_c`
--

DROP TABLE IF EXISTS `master_alloc_c`;
CREATE TABLE IF NOT EXISTS `master_alloc_c` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cust_name` varchar(150) COLLATE utf8_bin NOT NULL,
  `group_c` varchar(150) COLLATE utf8_bin NOT NULL,
  `del_date` date NOT NULL,
  `set_c_unit` longtext COLLATE utf8_bin NOT NULL,
  `length` longtext COLLATE utf8_bin NOT NULL,
  `neck` longtext COLLATE utf8_bin NOT NULL,
  `shoulder` longtext COLLATE utf8_bin NOT NULL,
  `sleeves` longtext COLLATE utf8_bin NOT NULL,
  `chest` longtext COLLATE utf8_bin NOT NULL,
  `stomach` longtext COLLATE utf8_bin NOT NULL,
  `seat` longtext COLLATE utf8_bin NOT NULL,
  `checks` varchar(150) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `master_alloc_c`
--

INSERT INTO `master_alloc_c` (`id`, `cust_name`, `group_c`, `del_date`, `set_c_unit`, `length`, `neck`, `shoulder`, `sleeves`, `chest`, `stomach`, `seat`, `checks`) VALUES
(1, ' Sujit', 'JANAT', '2021-03-31', 'shirt', '12.5', '3.25', '9.8', '1.4', '6.5', '7.9', '98.54', 'on'),
(2, ' Mukesh', 'JANAT', '2021-03-30', 'shirt,kurta', '12.3,1.2', '2.6,2.6', '2.3,1.3', '5.6,1.3', '9.8,1.2', '4.6,8.9', '1.2,98.2', 'on'),
(3, ' Mavli', 'JANAT', '2021-03-25', '10.5', '2.5', '5.6', '3.2', '9.8', '1.5', '3.1', '5.3', 'on'),
(4, ' Suhani', 'JANAT', '2021-03-23', '10.2', '20.5', '2.3', '15', '1.2', '1.2', '10', '50', 'on');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer_a`
--

DROP TABLE IF EXISTS `tbl_customer_a`;
CREATE TABLE IF NOT EXISTS `tbl_customer_a` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_date` date NOT NULL,
  `receipt_no` varchar(150) COLLATE utf8_bin NOT NULL,
  `group_a` varchar(150) COLLATE utf8_bin NOT NULL,
  `set_a_name` varchar(150) COLLATE utf8_bin NOT NULL,
  `set_a_unit` int(11) NOT NULL,
  `cust_name` varchar(150) COLLATE utf8_bin NOT NULL,
  `cust_address` varchar(150) COLLATE utf8_bin NOT NULL,
  `cust_mob` bigint(10) NOT NULL,
  `price` int(11) NOT NULL,
  `amt_paid` int(11) NOT NULL,
  `tot_left` int(11) NOT NULL,
  `del_date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `tbl_customer_a`
--

INSERT INTO `tbl_customer_a` (`id`, `purchase_date`, `receipt_no`, `group_a`, `set_a_name`, `set_a_unit`, `cust_name`, `cust_address`, `cust_mob`, `price`, `amt_paid`, `tot_left`, `del_date`, `created_at`) VALUES
(1, '2021-02-01', 'R350832', 'ASIF', 'suit,jodhpuri', 2, 'Ganesh', 'Ganesh nagar', 123456789, 9700, 9000, 0, '2021-02-18', '2021-02-27 23:38:59'),
(3, '2021-03-01', 'R264858', 'ASIF', 'jodhpuri,indowestern ', 2, 'Rahul', 'Rahul Nagar', 123456789, 9897, 4454, 5443, '2021-03-05', '2021-03-03 01:22:07'),
(6, '2021-03-02', 'R384962', 'ASIF', 'suit,jodhpuri ', 2, 'Mukesh', 'asdsa', 123456789, 1000, 500, 500, '2021-03-05', '2021-03-03 02:00:02'),
(7, '2021-03-01', 'R56945', 'ASIF', 'sherwani,jodhpuri ', 2, 'Pablo', 'skdksal', 3232, 998, 97, 901, '2021-03-25', '2021-03-03 02:01:24'),
(8, '2021-03-08', 'R9025', 'ASIF', 'jodhpuri,indowestern ', 2, 'Sahlu', 'askla', 665, 998, 998, 0, '2021-03-19', '2021-03-03 02:03:33'),
(10, '2021-03-01', 'R171890', 'ASIF', 'jodhpuri,indowestern ', 2, 'Andrew', 'sadsd', 56, 569, 66, 503, '2021-02-10', '2021-03-03 02:17:44'),
(11, '2021-03-04', 'R313280', 'ASIF', 'sherwani,jodhpuri ', 2, 'Sahlu', 'ads', 9893684778, 7500, 122, 7378, '2021-03-24', '2021-03-03 02:25:32'),
(17, '2021-03-03', 'R54319', 'ASIF', 'jodhpuri ', 1, 'Sundar', 'Ahemdabad', 9893684778, 9800, 5200, 4600, '2021-03-24', '2021-03-05 02:39:38'),
(14, '2021-03-05', 'R302656', 'ASIF', 'sherwani,jodhpuri ', 2, 'Rahul', 'as', 123456789, 9800, 522, 9278, '2021-03-25', '2021-03-03 03:16:42');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer_b`
--

DROP TABLE IF EXISTS `tbl_customer_b`;
CREATE TABLE IF NOT EXISTS `tbl_customer_b` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_date` date NOT NULL,
  `receipt_no` varchar(150) COLLATE utf8_bin NOT NULL,
  `group_b` varchar(150) COLLATE utf8_bin NOT NULL,
  `set_b_name` varchar(150) COLLATE utf8_bin NOT NULL,
  `set_b_unit` int(11) NOT NULL,
  `cust_name` varchar(150) COLLATE utf8_bin NOT NULL,
  `cust_address` varchar(150) COLLATE utf8_bin NOT NULL,
  `cust_mob` bigint(10) NOT NULL,
  `price` int(11) NOT NULL,
  `amt_paid` int(11) NOT NULL,
  `tot_left` int(11) NOT NULL,
  `del_date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `tbl_customer_b`
--

INSERT INTO `tbl_customer_b` (`id`, `purchase_date`, `receipt_no`, `group_b`, `set_b_name`, `set_b_unit`, `cust_name`, `cust_address`, `cust_mob`, `price`, `amt_paid`, `tot_left`, `del_date`, `created_at`) VALUES
(20, '2021-03-01', 'R17014', 'ARMAN', 'pant,pyjama ', 2, 'Raghu', 'Dhayri,Pune', 1234567890, 4500, 2000, 0, '2021-03-20', '2021-03-08 23:15:42'),
(18, '2021-03-01', 'R299516', 'ARMAN', 'pant,pyjama ', 2, 'Tumkur', 'gavandi nagar', 9893684748, 9500, 8000, 0, '2021-03-16', '2021-03-05 23:20:24'),
(19, '2021-03-10', 'R265788', 'ARMAN', 'pant ', 1, 'Mohin', 'Dahryi, pune', 9999425647, 7800, 1500, 6300, '2021-03-08', '2021-03-07 01:37:47');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer_c`
--

DROP TABLE IF EXISTS `tbl_customer_c`;
CREATE TABLE IF NOT EXISTS `tbl_customer_c` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_date` date NOT NULL,
  `receipt_no` varchar(150) COLLATE utf8_bin NOT NULL,
  `group_c` varchar(150) COLLATE utf8_bin NOT NULL,
  `set_c_name` varchar(150) COLLATE utf8_bin NOT NULL,
  `set_c_unit` int(11) NOT NULL,
  `cust_name` varchar(150) COLLATE utf8_bin NOT NULL,
  `cust_address` varchar(150) COLLATE utf8_bin NOT NULL,
  `cust_mob` bigint(10) NOT NULL,
  `price` int(11) NOT NULL,
  `amt_paid` int(11) NOT NULL,
  `tot_left` int(11) NOT NULL,
  `del_date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `tbl_customer_c`
--

INSERT INTO `tbl_customer_c` (`id`, `purchase_date`, `receipt_no`, `group_c`, `set_c_name`, `set_c_unit`, `cust_name`, `cust_address`, `cust_mob`, `price`, `amt_paid`, `tot_left`, `del_date`, `created_at`) VALUES
(4, '2021-03-05', 'R345418', 'JANAT', 'shirt ', 1, 'Suhani', 'Malva mill', 123456789, 9800, 1500, 8300, '2021-03-23', '2021-03-07 00:24:04'),
(5, '2021-03-04', 'R12016', 'JANAT', 'shirt ', 1, 'Rajesh', 'Balaji nagar', 123456789, 9800, 500, 9300, '2021-03-08', '2021-03-07 01:38:58');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_group`
--

DROP TABLE IF EXISTS `tbl_group`;
CREATE TABLE IF NOT EXISTS `tbl_group` (
  `grp_id` int(10) NOT NULL AUTO_INCREMENT,
  `group_a` varchar(150) COLLATE utf8_bin NOT NULL,
  `group_b` varchar(150) COLLATE utf8_bin NOT NULL,
  `group_c` varchar(150) COLLATE utf8_bin NOT NULL,
  `cat_id` int(11) NOT NULL,
  PRIMARY KEY (`grp_id`),
  UNIQUE KEY `cat_id` (`cat_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `tbl_group`
--

INSERT INTO `tbl_group` (`grp_id`, `group_a`, `group_b`, `group_c`, `cat_id`) VALUES
(1, 'ASIF', 'ARMAN', 'JANAT', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_set_a`
--

DROP TABLE IF EXISTS `tbl_set_a`;
CREATE TABLE IF NOT EXISTS `tbl_set_a` (
  `SET_a_id` int(11) NOT NULL,
  `group_a` varchar(150) COLLATE utf8_bin NOT NULL,
  `set_a_name` varchar(150) COLLATE utf8_bin NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `tbl_set_a`
--

INSERT INTO `tbl_set_a` (`SET_a_id`, `group_a`, `set_a_name`) VALUES
(1, 'ASIF', 'suit'),
(2, 'ASIF', 'sherwani'),
(3, 'ASIF', 'jodhpuri'),
(4, 'ASIF', 'indowestern'),
(5, 'ASIF', 'vestcoat'),
(6, 'ASIF', 'modicoat');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_set_b`
--

DROP TABLE IF EXISTS `tbl_set_b`;
CREATE TABLE IF NOT EXISTS `tbl_set_b` (
  `SET_b_id` int(10) NOT NULL,
  `group_b` varchar(150) COLLATE utf8_bin NOT NULL,
  `set_b_name` varchar(150) COLLATE utf8_bin NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `tbl_set_b`
--

INSERT INTO `tbl_set_b` (`SET_b_id`, `group_b`, `set_b_name`) VALUES
(1, 'ARMAN', 'pant'),
(2, 'ARMAN', 'pyjama'),
(3, 'ARMAN', 'churidar'),
(4, 'ARMAN', 'salwar');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_set_c`
--

DROP TABLE IF EXISTS `tbl_set_c`;
CREATE TABLE IF NOT EXISTS `tbl_set_c` (
  `SET_c_id` int(10) NOT NULL,
  `group_c` varchar(150) COLLATE utf8_bin NOT NULL,
  `set_c_name` varchar(150) COLLATE utf8_bin NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `tbl_set_c`
--

INSERT INTO `tbl_set_c` (`SET_c_id`, `group_c`, `set_c_name`) VALUES
(1, 'JANAT', 'shirt'),
(2, 'JANAT', 'kurta');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_unit_a`
--

DROP TABLE IF EXISTS `tbl_unit_a`;
CREATE TABLE IF NOT EXISTS `tbl_unit_a` (
  `SET_a_id` int(11) NOT NULL AUTO_INCREMENT,
  `set_a_unit` varchar(150) COLLATE utf8_bin NOT NULL,
  `length` longtext COLLATE utf8_bin NOT NULL,
  `neck` longtext COLLATE utf8_bin NOT NULL,
  `shoulder` longtext COLLATE utf8_bin NOT NULL,
  `chest` longtext COLLATE utf8_bin NOT NULL,
  `stomach` longtext COLLATE utf8_bin NOT NULL,
  `seat` longtext COLLATE utf8_bin NOT NULL,
  `sleeves` longtext COLLATE utf8_bin NOT NULL,
  `checks` varchar(150) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`SET_a_id`)
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `tbl_unit_a`
--

INSERT INTO `tbl_unit_a` (`SET_a_id`, `set_a_unit`, `length`, `neck`, `shoulder`, `chest`, `stomach`, `seat`, `sleeves`, `checks`) VALUES
(33, 'df', '43', '34', '45', '56', '56', '56', '56', 'on'),
(34, 'vestcoat', '12', '323', '23', '23', '34', '34', '34', 'on'),
(36, 'df', '2', '23', '23', '23', '23', '23', '23', 'on'),
(37, 'modicoat', '15', '50', '52', '52', '52', '52', '52', 'on'),
(38, 'indowestern,joshpuri', '15.6,1.2', '6.9,6.5', '7.9,1.2', '4.8,3.2', '9.8,7.8', '1.3,9.8', '6.5,5.6', 'on'),
(39, 'jodhpuri', '8.2', '6.5', '1.2', '6.3', '9.8', '4.5', '5.2', 'on');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_unit_b`
--

DROP TABLE IF EXISTS `tbl_unit_b`;
CREATE TABLE IF NOT EXISTS `tbl_unit_b` (
  `SET_b_id` int(11) NOT NULL AUTO_INCREMENT,
  `set_b_unit` varchar(150) COLLATE utf8_bin NOT NULL,
  `length` longtext COLLATE utf8_bin NOT NULL,
  `waist` longtext COLLATE utf8_bin NOT NULL,
  `seat` longtext COLLATE utf8_bin NOT NULL,
  `fork` longtext COLLATE utf8_bin NOT NULL,
  `thigh` longtext COLLATE utf8_bin NOT NULL,
  `knee` longtext COLLATE utf8_bin NOT NULL,
  `bottom` longtext COLLATE utf8_bin NOT NULL,
  `checks` varchar(150) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`SET_b_id`)
) ENGINE=MyISAM AUTO_INCREMENT=44 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `tbl_unit_b`
--

INSERT INTO `tbl_unit_b` (`SET_b_id`, `set_b_unit`, `length`, `waist`, `seat`, `fork`, `thigh`, `knee`, `bottom`, `checks`) VALUES
(43, 'paint,pyjama', '12.2,14.2', '3.2,1.3', '6.5,6.5', '5.9,9.8', '4.5,4.7', '4.2,5.6', '9.9,9.8', 'on'),
(42, 'churidar,salwar,', '1.5,1.9,', '20,3.3,', '1.3,8.9,', '6.5,5.6,', '8.9,4.7,', '8.9,6.5,', '5.6,2.1,', 'on');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_unit_c`
--

DROP TABLE IF EXISTS `tbl_unit_c`;
CREATE TABLE IF NOT EXISTS `tbl_unit_c` (
  `SET_c_id` int(11) NOT NULL AUTO_INCREMENT,
  `set_c_unit` varchar(150) COLLATE utf8_bin NOT NULL,
  `length` longtext COLLATE utf8_bin NOT NULL,
  `neck` longtext COLLATE utf8_bin NOT NULL,
  `shoulder` longtext COLLATE utf8_bin NOT NULL,
  `sleeves` longtext COLLATE utf8_bin NOT NULL,
  `chest` longtext COLLATE utf8_bin NOT NULL,
  `stomach` longtext COLLATE utf8_bin NOT NULL,
  `seat` longtext COLLATE utf8_bin NOT NULL,
  `checks` varchar(150) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`SET_c_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `tbl_unit_c`
--

INSERT INTO `tbl_unit_c` (`SET_c_id`, `set_c_unit`, `length`, `neck`, `shoulder`, `sleeves`, `chest`, `stomach`, `seat`, `checks`) VALUES
(1, 'shirt', '12.5', '3.25', '9.8', '98.54', '1.4', '6.5', '7.9', 'on'),
(2, 'shirt,kurta', '12.3,1.2', '2.6,2.6', '2.3,1.3', '1.2,98.2', '5.6,1.3', '9.8,1.2', '4.6,8.9', 'on'),
(3, '10.5', '2.5', '5.6', '3.2', '5.3', '9.8', '1.5', '3.1', 'on'),
(4, '10.2', '20.5', '2.3', '15', '50', '1.2', '1.2', '10', 'on');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `first_name`, `last_name`, `mobile`, `address`) VALUES
(1, 'admin@admin.com', '12345', 'var', 'paksh', 123456789, 'hadapsar');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
