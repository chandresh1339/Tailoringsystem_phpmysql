<?php error_reporting(0);

include('config.php');

//Getting id from the url 
$id=$_GET['id'];
echo $id;

$sql = "DELETE  FROM tbl_customer_a WHERE id='".$id."'";

	$result=mysqli_query($con,$sql);

	if($result)
	{

		echo "<script language='javascript'>alert('Assignment of Group A-Deleted Successfully')
		window.location = 'view_customers_A.php';
           </script>";

        	}

        		else{

            echo "Error in deleting record" . mysqli_error($con);
          		}
     ?>
