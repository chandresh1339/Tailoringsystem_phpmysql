<script src="UNIT-C.js"></script>
<script>history.pushState({}, "", "")</script>
<body style="background-color:pink;">
        <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
          <table class="table table-bordered table-hover" id="invoiceItem"> 
            <tr><th width="2%"><input id="checkAll" class="formcontrol" type="checkbox">
            </th>
              
              <th width="10%">Set C</th>
              <th width="10%">Length</th>
              <th width="10%">Neck</th>
              <th width="10%">Shoulder</th>               
              <th width="10%">Chest</th>
              <th width="10%">Stomach</th>
              <th width="10%">Seat</th>
              <th width="10%">Sleeves</th>
            </tr>             
            <tr>
              
              <td><input class="itemRow" type="checkbox" name="checkbox[]"></td>
              <td><input type="text" name="set_c_unit[]" id="set_c_unit" class="form-control" autocomplete="off"></td>
              <td><input type="float" name="length[]"  id="length" class="form-control" autocomplete="off"></td>
              <td><input type="float" name="neck[]" id="neck" class="form-control" autocomplete="off"></td>      
              <td><input type="float" name="shoulder[]" id="shoulder"  class="form-control" autocomplete="off"></td>
              <td><input type="float" name="chest[]" id="chest"  class="form-control" autocomplete="off"></td>
              <td><input type="float" name="stomach[]" id="stomach" class="form-control" autocomplete="off"></td>
              <td><input type="float" name="seat[]" id="seat"  class="form-control" autocomplete="off"></td>
              <td><input type="float" name="sleeves[]" id="sleeves" class="form-control" autocomplete="off"></td>
              
            </tr>           
          </table>
        </div>
      </div>
      <div class="row">
        <div class="col-xs-12 col-sm-3 col-md-3 col-lg-3">
          <button class="btn btn-danger delete" id="removeRows" type="button">- Delete</button>
          <button class="btn btn-success" id="addRows" type="button">+ Add More</button>
        </div>
      </div>
      <!--<div class="row"> 
        <div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
          <h3>Notes: </h3>
          <div class="form-group">
            <textarea class="form-control txt" rows="3" name="notes" id="notes" placeholder="Your Notes"></textarea>
          </div>
          <br>

          <div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
            <div class="form-group">
            <input type="hidden" name="SET_a_id" class="form-control">
          </div>
                </div>
           <div >
-->
<br/>

                    <input type="submit" name="btnmeasure" class="btn btn-success " value="SAVE">

                </div>
        </div>

      </div>
    </body>



