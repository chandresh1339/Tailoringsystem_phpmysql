<?php

 if($_SERVER['HTTP_HOST'] != 'localhost'){
     $con=mysqli_connect('localhost','root','','invoice');
 }else{
    $con=mysqli_connect('localhost','root','','invoice'); 
 }

if(!$con){
	die("Failed to Establish Database Connection");


}