	
<?php error_reporting(0); 
include('header_scripts.php');
include('menu.php');
include('config.php');

?>

<script src="UNIT-B.js"></script>
<script>history.pushState({}, "", "")</script>
			<body>


				<a href="index.php" class="btn btn-secondary" style="margin:10px;">Back</a>
                        <a href="measure_a.php" class="btn btn btn-primary" style="margin:10px;">GROUP A</a>
                         <a href="measure_b.php" class="btn btn btn-warning" style="margin:10px;">GROUP B</a>
                          <a href="measure_c.php" class="btn btn btn-danger" style="margin:10px;">GROUP C</a>
                  <br/><br/>
			<div id="search">
			   <form action="" method="post" class="widget_search">

			    <div style="text-align: center;">
			    	<label>Search Customer:</label>&nbsp;&nbsp;&nbsp;&nbsp;
			    <input class="search" type="text"  placeholder="Customer Name"  name="search" id="search">

			    <input type="submit" value="Search" class="btn btn btn-info"/>
			   <input type="reset" class="btn btn btn-danger" value="Reset" onclick="window.location='measure_b.php'">
			    </div>
			  </form>
			</div>

					<div>
					<?php include('search_assign_b.php');?>
				
				</div>

				<div style="text-align: center;">		
				
						<form method='get' action="RASID-B.php?receipt_no" class="widget_search" >
							<label>Select Invoice:</label>&nbsp;&nbsp;&nbsp;&nbsp;
						<select name='receipt_no' class="form-group" >
							<?php

							$sql="SELECT * FROM tbl_customer_b";

							$result=mysqli_query($con,$sql);

							while($invoice=mysqli_fetch_array($result)){
								echo "<option value='".$invoice['receipt_no']."'>".$invoice['receipt_no']."</option>";
								 }
						?>
						</select>&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="submit" name="submit" value="Generate" class="btn btn btn-secondary">
									</form>
									</div>
								</body>
								
								
				