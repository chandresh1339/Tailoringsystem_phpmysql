<?php error_reporting(0); include('header_scripts.php');  $date = date("Y.m.d");?>

<link rel="stylesheet" href="public/style.css">
<style>
footer {
 
  position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color:#202020;
   color: white;
   text-align: center;
}
}
</style>

  <body>
<div class="topnav" id="myTopnav">
  <a href="index.php">DASHBOARD</a>
  <a href="measure_a.php">Reports(Group A) </a>
   <a href="measure_b.php">Reports(Group B)</a>
      <a href="measure_c.php">Reports(Group C)</a>
      <li><a href="rpt_due_A.php">Find Due Amount</a>
    </li>
  <a href="javascript:void(0);" class="icon" onclick="myFunction()">
    <i class="fa fa-bars"></i>
  </a>
</div>
  <div > <h3 style="margin:15px; color:blue" class="text-center" align="center">Today's Delivery</h3>
                    </div>

        <?php include('to_delivery_A.php');
        include('to_delivery_B.php');
        include('to_delivery_C.php');
         
        ?>
 
<footer>
  <p>Tailoring System<br>
  <a href="mailto:abc@example.com">A way to paperless...</a></p>
</footer>