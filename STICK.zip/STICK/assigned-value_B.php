<script>history.pushState({}, "", "")</script>
<?php //error_reporting(0); 
        
    if(isset($_POST['btnmeasure']) and !empty($_POST)){
        

        $check = $_POST['checkbox'];
            if(isset($_POST['checkbox'])) {
                foreach($_POST['checkbox'] as $check) {

                    //Getting searched values from customer form
                     $id = $_GET['id'];
                     //echo $id;
                    $cust_name=$row['cust_name'];
                    //echo $cust_name;
                    $group_b=$row['group_b'];
                    $del_date=$_POST['del_date'];   
                  
       

                   $check = implode(',', $_POST['checkbox']);
                  $set_b_unit  = implode(',', $_POST['set_b_unit']);
                  $length = implode(',',$_POST['length']);
                   $waist = implode(',',$_POST['waist']);
                   $seat = implode(',',$_POST['seat']);
                  $fork = implode(',',$_POST['fork']);
                  $thigh= implode(',',$_POST['thigh']);
                   $knee= implode(',',$_POST['knee']);
                   $bottom=implode(',',$_POST['bottom']);
               /* echo $check . "<br>";
                echo $set_a_unit . "<br>";
                echo $length . "<br>";
                 echo $neck . "<br>";
                  echo $shoulder . "<br>";
                   echo $chest . "<br>";
                    echo  $stomach . "<br>";
                     echo  $seat . "<br>";
                     echo  $sleeves. "<br>";*/
                 $sql="INSERT INTO tbl_unit_b(set_b_unit,length,waist,seat,fork,thigh,knee,bottom,checks) VALUES('$set_b_unit','$length','$waist','$seat','$fork','$thigh','$knee','$bottom','$check')";

                   $result = mysqli_query($con, $sql);
               }
               
         } 
                if($result)
                {
                     $sql0 = "SELECT * FROM tbl_customer_b WHERE id = '".$id."'";
             
                     $result0 = mysqli_query($con, $sql0);
                 }
                     if($result0)
                     {
           $qry = "INSERT INTO master_alloc_b VALUES(null,' $cust_name','$group_b','$del_date','$set_b_unit','$length','$waist','$seat','$fork','$thigh','$knee','$bottom','$check')";
                $result1 = mysqli_query($con, $qry);
            }

             if ($result1) {
     
                    echo "<script language='javascript'>alert('Record Inserted Successfully')
                   </script>";
                                    } else {
                                      //echo  $con->error;
                            echo "Failure" . mysqli_error($con);
                                }

}?>
