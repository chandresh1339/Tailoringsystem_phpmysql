<!-- Load an icon library to show a hamburger menu (bars) on small screens -->

<?php error_reporting(0); include('header_scripts.php'); $date = date("Y.m.d"); ?>

<link rel="stylesheet" href="public/style.css">

<body>
<div class="topnav" id="myTopnav">
<li  align="center"  >
 <a href="#home"><img src="tailor_logo.JPG" width="75px"></a>
</li>
  <a href="index.php">DASHBOARD</a>
  <a href="assign-a.php">Assignment</a>
  <a href="view_customers_A.php">Group A</a>
   <a href="view_customers_B.php">Group B</a>
      <a href="view_customers_C.php">Group C</a>
      <a href="global_search.php">Global Search</a>
      <a href="view_units_A.php">View Units</a>
  
  <a href="javascript:void(0);" class="icon" onclick="myFunction()">
    <i class="fa fa-bars"></i>
  </a>

</div>
<div style="padding-left:16px">
Today is:   <font style="color:blue;" size="5"> <?php echo $date;?></font>
</div>


<script>
function myFunction() {
  var x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
}
</script>

 

 <!--<a href="#home"><img src="public/images/SCM.png"></a>-->
</div>

<?php include('to_delivery_A.php');
      include('to_delivery_B.php');
      include('to_delivery_C.php');


?>
