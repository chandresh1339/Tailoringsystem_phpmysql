<?php error_reporting(0);
 
include ('config.php');
 
 //getting id from url

    $id = $_GET['id'];
  //echo $id;
    $sql = "SELECT * FROM tbl_customer_a WHERE id = '".$id."'";
    $result = mysqli_query($con,$sql);
  $row =mysqli_fetch_array($result);

 
?>
 
<!DOCTYPE html>
<html>
<head>
    <title>Edit Customer</title>
 
    <style type="text/css">
        fieldset {
            margin: auto;
            margin-top: 100px;
            width: 50%;
        }
 
        table tr th {
            padding-top: 20px;
        }
    </style>
 
</head>
<body>
 
<fieldset>
    <legend>Edit Customer</legend>
 
    <form action="update_customer_A.php" method="post">
        <table cellspacing="0" cellpadding="0">
            <tr>
                <th>Name</th>
                <td><input type="text" name="cust_name" placeholder="Customer Name" value="<?php echo $row['cust_name'] ?>" /></td>
            </tr>     
            <tr>
                <th>Contact</th>
                <td><input type="text" name="cust_mob" placeholder="Customer Mob#" value="<?php echo $row['cust_mob'] ?>" /></td>
            </tr>
            <tr>
                <th>Address</th>
                <td><input type="text" name="cust_address" placeholder="Customer Address" value="<?php echo $row['cust_address'] ?>" /></td>
            </tr>
           
               <tr>
                <th>Amt Paid</th>
                <td><input type="text" name="amt_paid" placeholder="Amt Paid" value="<?php echo $row['amt_paid'] ?>" /></td>
            </tr>

             <tr>
                <th>Amt Left</th>
                <td><input type="text" name="tot_left" placeholder="Amt Left" value="<?php echo $row['tot_left'] ?>" /></td>
            </tr>
           

                <input type="hidden" name="id" value="<?php echo $row['id']?>" />

                <td><input type="submit" name="update" value="Update" ></td>
                <td><a href="view_customers_A.php"><button type="button" >Back</button></a></td>
            </tr>
        </table>
    </form>
 
</fieldset>
 
</body>
</html>
