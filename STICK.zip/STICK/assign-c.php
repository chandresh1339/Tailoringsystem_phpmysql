<?php error_reporting(0);   include('header_scripts.php');
                 
include('config.php');
include('menu.php');
$purchase_date = mysqli_real_escape_string($con, $_POST['purchase_date']);
$receipt_no = mysqli_real_escape_string($con, $_POST['receipt_no']);
$group_c = mysqli_real_escape_string($con, $_POST['group_c']);
$set_c_name =$_POST['set_c_name'];
//$set_a_unit =$_POST['set_a_unit'];
$cust_name = mysqli_real_escape_string($con, $_POST['cust_name']);
$cust_address = mysqli_real_escape_string($con, $_POST['cust_address']);
$cust_mob = mysqli_real_escape_string($con, $_POST['cust_mob']);
$price= mysqli_real_escape_string($con, $_POST['price']);
$amt_paid = mysqli_real_escape_string($con, $_POST['amt_paid']);
$tot_left= mysqli_real_escape_string($con, $_POST['tot_left']);
$del_date= mysqli_real_escape_string($con, $_POST['del_date']);

//array to string conversion
$strcheck=implode(",",$set_c_name);
//echo $strcheck;
$set_c_unit=count($set_c_name);
//echo $set_a_unit;



if (!empty($_POST)) {

    $sql = "INSERT INTO `tbl_customer_c` VALUES(null,'$purchase_date','$receipt_no','$group_c','$strcheck ','$set_c_unit','$cust_name','$cust_address','$cust_mob',' $price','$amt_paid','$tot_left','$del_date','" . date('Y-m-d H:i:s') . "')";

   $result = mysqli_query($con, $sql);
   
       if ($result) {

  		
       
		            echo "<script language='javascript'>alert('Record Inserted Successfully')
		           </script>";
		        					} else {
            				echo "Failure" . mysqli_error($con);
        						}
      	}
   
 ?>


    <!DOCTYPE html>
    <html>
        <head>
            <title>GROUP-C Information</title>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
          

            <script type=text/javascript>
                function minus() {
                    var price = document.getElementById('price').value;
                    var amt_paid = document.getElementById('amt_paid').value;
                    var result = parseInt(price) - parseInt(amt_paid);
                    console.log(result);
                    if (!isNaN(result)) {
                        document.getElementById('tot_left').value = result;
                    }
                }


                function phonenumber(cust_mob)
                        {
                          var phoneno = /^\d{10}$/;
                          if(cust_mob.value.match(phoneno))
                            {
                              return true;
                                }
                             else
                                {
                             alert("Not a valid Phone Number");
                             return false;
                                }
                          }

                         
            </script>
            <script>history.pushState({}, "", "")</script>
                        <script>  function valiDate()
                          {
                             var date1=document.getElementById("purchase_date");
                             var varDate1 = new Date(date1); //dd-mm-YYYY
                            var date2=document.getElementById("del_date");
                            var varDate2 = new Date(date2); //dd-mm-YYYY

                            if(varDate2>=varDate1)
                                    {
                                        return true;
                                      }
                                    else{
                                        alert("Delivery date should be greater than or equal to Purchase date");
                                        return false;

                                            }
                          }</script>
        </head>
        <body style="background-color:pink;">

            <form  action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post" name="form1"  class="form-inline">


                <div class="container" align="center"  >
                    <div >
                        <a href="index.php" class="btn btn-secondary" style="margin:10px;">Back</a>
                        <a href="assign-a.php" class="btn btn btn-primary" style="margin:10px;">GROUP A</a>
                         <a href="assign-b.php" class="btn btn btn-warning" style="margin:10px;">GROUP B</a>
                          <a href="assign-c.php" class="btn btn btn-danger" style="margin:10px;">GROUP C</a>
                    </div>

                    <div >
                        <h3 style="margin:15px;" class="text-center" align="center">Customer Information</h3>
                    </div>
                                   
                      </div>
<table class="table table table-striped table-bordered" >
        <tr width="75%">
        <th style="width:50px;">Purchase Date</th>
         <th style="width:50px;">Recepit#</th>
   
          <th style="width:50px;">Group A</th>
           <th style="width:50px;">Select Sets:</th>
        </tr>
          
                    <tr>
                        <td>
               
                       

                        <input type="date" id="purchase_date" name="purchase_date" placeholder="Purchase Date" required="required"></td>

                      <td>
                     

                        <input type="text" name="receipt_no" readonly placeholder="Receipt no." required="required" value="<?php $r = rand(400, 400000);
                            echo "R" . $r;
                                ?>" class="form-control"></td>
                     <td>
                     

                        <input type="text" name="group_c" readonly placeholder="Group C"  value="<?php $q = "SELECT group_c FROM tbl_set_c ";  $r = mysqli_query($con, $q);
								 $row = mysqli_fetch_assoc($r);
                                 echo $row['group_c'];?>" ></td>
                  
                     <td>
                  
                <input type="checkbox" name="set_c_name[]" value="shirt" class="form-check-input">shirt<br/>
                <input type="checkbox" name="set_c_name[]" value="kurta" class="form-check-input">kurta<br/>
               
                </td>
<td>
 <a href="measure_c.php" class="btn btn btn-danger" style="margin:10px;">GROUP C</a>
</td>
            <!-- <div> 
                    <input type="hidden" name="set_a_unit"  placeholder="set_a_unit" required="required" class="form-control" value="<?php echo count($set_a_name);?>">

                    </div>-->
 

                </tr>
              <table class="table table table-striped table-bordered">        
                <tr width="75%" >
                <th style="width:50px;">Customer Name</th>
              <th style="width:50px;">Customer Address</th>
               <th style="width:50px;">Customer Mob#</th>
               <th style="width:50px;">Price</th>
               <th style="width:50px;">Amt_paid</th>
               <th style="width:50px;">Total_left</th>
               <th style="width:50px;">Delivery date</th>
            
        </tr>

                <tr>
                       <td>
                               <input type="text" name="cust_name"  placeholder="Customer Name" required="required" >
               </td>

				
                        	<!--<label for="_id">Customer Id</label>-->

                        		<input type="hidden" name="id"  placeholder="id" >
                    <td>
                  
							
                        <textarea name="cust_address" placeholder="Address"  required="required"></textarea>
                </td>
                 
                    
                  <td>
                    

                        <input type="number" name="cust_mob"  placeholder="Customer Mobile" onclick="phonenumber(document.form1.cust_mob)" required="required" >
                     </td>
                   


              <td>
                  

                    <input type="text" name="price" id="price" onkeyup="minus()" placeholder="price"  >
                </td>
                   
              

                  <td>
              
                 

                    <input type="text" name="amt_paid" id="amt_paid" onkeyup="minus()" placeholder="amt_paid"   onkeyup="minus(this.value)"><script type="text/javascript">

                        $("#amt_paid").click(function () {

                            $("#amt_paid").disabled = true;
                        });
                    </script>
             

                </td>
                   
                                   <td>
            

                    <input type="text" name="tot_left" id="tot_left" placeholder="tot_left"  onkeyup="minus(this.value)"><script type="text/javascript">

                        $("#tot_left").click(function () {

                            $("#tot_left").disabled = true;
                        });
                    </script>

            </td>
              
					     <td>
                       

                        <input type="date" id="del_date" name="del_date" onclick="valiDate()" placeholder="Delivery date" required="required" >

                 </td>



</tr>
</table>
         <div>
                    <input type="submit" name="myButton" class="btn btn-success "  value="SAVE">
   </div>     
            </div>
   </table>

        </form>
    </body>
</html>
