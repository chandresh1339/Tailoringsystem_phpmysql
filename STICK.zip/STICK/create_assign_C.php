
<?php error_reporting(0);
 
include ('config.php');
include('menu.php');
 include('header_scripts.php');
//Getting searched values from customer form
              $id = $_GET['id'];
                    // echo $id;

              $qu = "SELECT * FROM tbl_customer_c WHERE id = '".$id."'";
				    $rs = mysqli_query($con,$qu);
				    $row =mysqli_fetch_array($rs);

   
//Allocate units
include('assigned-value_C.php');

?>
        
    


 <form action="" method="post">

              <input type="hidden"  readonly placeholder="id"  value="<?php 
              echo $row['id'];?>" >

 <div class="form-control" > <label for="cust_name">Customer Name</label>
              <input type="text"  readonly placeholder="cust_name" required="required" value="<?php 
              echo $row['cust_name'];?>" >
        
    <label for="group_a">Assigned</label>
              <input type="text"  readonly placeholder="group_c" required="required" value="<?php
              echo $row['group_c'];?>" >

                        <label for="del_date">Delivery date</label>

                        <input type="date" name="del_date" style="color:red" readonly placeholder="Delivery date" required="required" value="<?php
              echo $row['del_date'];?>">

                
                  
                        <label for="set_b_name">Current Set of C</label>

                        <input type="text" style="color:blue;" name="set_c_name" readonly placeholder="set_c_name" required="required"  value="<?php 
              echo $row['set_c_name'];?>">

                    <label for="receipt_no">Receipt#</label>

                        <input type="text" name="receipt_no" readonly placeholder="receipt_no" required="required"  value="<?php 
              echo $row['receipt_no'];?>">

          </div>

          <br/>
          <br/>
<?php include('allocate-c.php');?>

      </form>