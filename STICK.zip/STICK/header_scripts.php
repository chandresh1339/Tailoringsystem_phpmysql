 <meta name="viewport" content="width=device-width, initial-scale=1.0">
<script src="public/jquery-2.2.0.min.js"></script> 
<link rel="stylesheet" href="public/bootstrap_lib/css/bootstrap.min.css">
<link rel="stylesheet" href="public/bootstrap_lib/css/bootstrap-theme.css">
<link rel="stylesheet" href="public/bootstrap_lib/css/bootstrap.css">
<link rel="stylesheet" href="public/bootstrap_lib/css/bootstrap.css.map">
<script src="public/bootstrap_lib/js/bootstrap.min.js"></script>

<link rel="stylesheet" href="public/font-awesome-master/css/font-awesome.min.css">
<link rel="stylesheet" href="public/style.css">

<style>
    .shadow_box{
        box-shadow: 2px 5px 4px 5px #eeeeee;
    }
    </style>